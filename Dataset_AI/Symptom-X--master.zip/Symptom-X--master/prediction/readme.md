### Files
- data_pivoted.csv : Each row is a disease, columns are symptoms with 1/0 if present in disease
- symptoms_bench.csv : Key-Value pair of disease-symptom alone. Nothing else. Duplicate Values removed.
- NB Classifier.ipynb : Notebook with Naive Bayes experiment. 
