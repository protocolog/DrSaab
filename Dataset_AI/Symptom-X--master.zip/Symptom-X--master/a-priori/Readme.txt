apriori.py- File contains the implemented apriori algorithm with confidence calculation etc.
pass_x.csv - Output of a-priori passes noted
bucketmap.csv- Clean csv mapping diseases to symptoms
buckets.csv - Buckets of symptoms clustered together
freq-itemsets - Subgraph generation based on frequent itemsets from pass_5 of a-priori
