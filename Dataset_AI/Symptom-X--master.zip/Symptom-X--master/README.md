# Symptom-X-
Using available datasets of Symptoms X diseases, I generate a graph of the same with the subgraphs consisting of illness and symptom nodes. There would be two kinds of nodes- the Symptom or Factor node and the Disease node. Using Gephi for graph visualization.

Dataset Information:

Source: http://people.dbmi.columbia.edu/~friedma/Projects/DiseaseSymptomKB/index.html

Number of relations: 2,130

Number of diseases: 148

Number of symptoms: 805

Graph structure: The disease nodes point to the symptom nodes.

Currently clustered graph:

![](https://github.com/Deshna/Symptom-X-/blob/master/Images/Untitled4.png)
