### Symptom - Disease Classifier


Dataset: http://people.dbmi.columbia.edu/~friedma/Projects/DiseaseSymptomKB/index.html
